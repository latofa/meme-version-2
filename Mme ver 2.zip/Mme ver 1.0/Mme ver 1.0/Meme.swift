//
//  Meme.swift
//  Mme ver 1.0
//
//  Created by Mac on 12/03/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit

struct Meme {
    
    let topText: String!
    let bottomText: String!
    let originalImage: UIImage!
    let memedImage: UIImage!
}
