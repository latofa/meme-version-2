//
//  MemeCollectionCellVC.swift
//  Mme ver 1.0
//
//  Created by Mac on 23/03/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit

class MemeCollectionCellVC: UICollectionViewCell {

   

    @IBOutlet weak var imageView: UIImageView!

}
