//
//  MemeDetailsVC.swift
//  Mme ver 1.0
//
//  Created by Mac on 22/03/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit

class MemeDetailsVC: UIViewController , UIImagePickerControllerDelegate {
    
    
    var meme: Meme!
    
    @IBOutlet weak var imageView: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.isNavigationBarHidden = false
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            title: "Edit",
            style: .plain,
            target: self,
            action: #selector(Edit))
        
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tabBarController?.tabBar.isHidden = true
        self.imageView!.image = meme.memedImage
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.tabBarController?.tabBar.isHidden = false
    }
    
    // here we will allow the user to edite the currrent desplayed image
    @objc func Edit() {
        
        // Get the storyboard and ResultViewController
        let storyboard = UIStoryboard (name: "Main", bundle: nil)
        let resultVC = storyboard.instantiateViewController(withIdentifier: "MemeEditorViewController")as! MemeEditorViewController
        
        // here we invoke the finalImage from MemeEditorViewController
        // and give it the current desplayed image as a value
        resultVC.finalImage =  UIImage()
        resultVC.finalImage = meme.memedImage
        self.navigationController?.pushViewController(resultVC, animated: true)
        
    }
}
