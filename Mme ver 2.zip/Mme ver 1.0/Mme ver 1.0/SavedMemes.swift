//
//  SavedMemes.swift
//  Mme ver 1.0
//
//  Created by Mac on 24/03/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import Foundation

class SavedMemes {
    
 var memes = [Meme]()

}
